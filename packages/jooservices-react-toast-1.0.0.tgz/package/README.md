# @jooservices/react-toast

Global **toast** stack: imperative `toast.*` API + `<Toaster />` viewport.

UI follows Tailwind Plus–style **Simple** / **With actions below** notifications (white card, colored status icon, title + muted description, optional footer actions). Compatible with the XCrawlerII / XFlickr `toast.success/error/info` call shape.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/toast"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Usage

```ts
import "@jooservices/react-toast/styles.css";
import { Toaster, toast } from "@jooservices/react-toast";

// Mount once near the app root
<Toaster position="top-right" />

toast.success("Saved.");
toast.error("Failed to save.");
toast.info("Import is already queued.");
toast.warning("Dispatch skipped — already running.");
toast.loading("Saving…"); // sticky until replaced / dismissed

toast.success("Anyone with a link can now view this file.", {
  title: "Successfully saved!",
  action: { label: "Undo", onClick: () => undo() },
  secondaryAction: { label: "Dismiss", onClick: () => undefined },
});

toast.success("Kept on screen", { durationMs: 0 }); // sticky
toast.dismiss(id);
toast.dismissAll();

await toast.promise(save(), {
  loading: "Saving…",
  success: "Saved.",
  error: "Save failed.",
});
```

### `toast` API

| Method | Notes |
|--------|--------|
| `success` / `error` / `info` / `warning` / `loading` | `(message, durationMs?)` or `(message, options?)` |
| `promise` | loading → success/error, same `id` |
| `dismiss` / `dismissAll` | Remove one or all |

### Options

| Option | Role |
|--------|------|
| `id` | Stable id — replace an existing toast |
| `title` | Optional heading; message becomes muted description |
| `durationMs` | Auto-dismiss ms; `0` / `Infinity` = sticky |
| `action` | Primary footer action (dismisses after click) |
| `secondaryAction` | Secondary footer action (split “actions below”) |

Defaults: success/info/warning **4500ms**, error **6000ms**, loading **sticky**.

### `<Toaster />`

| Prop | Role |
|------|------|
| `position?` | `top-right` (default) \| `top-center` \| `bottom-right` |
| `maxVisible?` | Cap (default `5`) |
| `className?` | Extra viewport class |

Hover / focus pauses auto-dismiss and the progress bar.

## Peers

`react`, `react-dom`, `lucide-react`
