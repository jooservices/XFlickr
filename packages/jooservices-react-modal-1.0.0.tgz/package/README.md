# @jooservices/react-modal

Shared **Modal** dialog: portal overlay with compound **Header** / **Body** / **Footer**.

Does not extend `@jooservices/react-card` — regions mirror card layout for familiarity; overlay, focus, and a11y stay modal-owned.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/modal"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Usage

```ts
import "@jooservices/react-modal/styles.css";
import { Modal } from "@jooservices/react-modal";

<Modal open={open} onClose={() => setOpen(false)} size="md" titleId="confirm-title">
  <Modal.Header title="Confirm" />
  <Modal.Body>Are you sure?</Modal.Body>
  <Modal.Footer>
    <button type="button" onClick={() => setOpen(false)}>Cancel</button>
    <button type="button" onClick={onConfirm}>Confirm</button>
  </Modal.Footer>
</Modal>
```

### Props

| Prop | Role |
|------|------|
| `open` | Whether the dialog is shown |
| `onClose?` | Backdrop click, Escape, and Header close |
| `closeDisabled?` | Blocks close while true (e.g. submitting) |
| `size?` | `sm` \| `md` \| `lg` \| `xl` (default `md`) |
| `titleId?` | `aria-labelledby` for the dialog |
| `className?` | Overlay class |
| `panelClassName?` | Panel class |
| `zIndexClassName?` | Extra overlay stacking class |

### Regions

| Region | Notes |
|--------|--------|
| `Modal.Header` | `title` / `center` / `actions` / `showClose` (default true) |
| `Modal.Body` | Scrollable content |
| `Modal.Footer` | Action row (compose with action-buttons in apps) |

## Peers

`react`, `react-dom`, `lucide-react`
