# @jooservices/react-card

Shared card primitives: **BaseCard** (header / content / footer shell) and **StatCard** (dashboard metrics).

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/card"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Usage

```ts
import "@jooservices/react-card/styles.css";
import { BaseCard, StatCard } from "@jooservices/react-card";
import { Boxes } from "lucide-react";

<BaseCard
  icon={<Boxes />}
  title="Section"
  subtitle="Optional support line"
  actions={<button type="button">Action</button>}
  footer="Optional footer"
>
  Free content
</BaseCard>

<StatCard
  label="Packages"
  value={9}
  subtext="Package demos"
  icon={<Boxes />}
  info="What this metric means."
  tone="cyan"
  footer={<a href="/docs">Docs</a>}
/>
```

### BaseCard slots

| Slot | Prop | Notes |
|------|------|--------|
| Header leading | `icon?` | Optional visual identity |
| Header title | `title?` / `subtitle?` | Left column |
| Header actions | `actions?` | Right; compose with action-buttons when needed |
| Content | `children` | Free body |
| Footer | `footer?` | Divided bottom region |

### StatCard

Built on BaseCard. Uses a small uppercase `label`, large `value` (numbers get `toLocaleString()`), optional `subtext`, optional leading `icon`, and optional `info` (CircleHelp control with tooltip explaining the metric). Extra `actions` render after the info control.

`tone`: `slate` \| `cyan` \| `amber` \| `emerald` \| `rose` (colors the value).

## Peers

`react`, `react-dom`, `lucide-react`
