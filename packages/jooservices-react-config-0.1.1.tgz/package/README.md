# @jooservices/react-config

Schema-driven configuration panel for React — declarative tabs, grouped browse rows, modal editor, optional raw store tab, and a **General** fallback for unmapped groups.

## Install

```bash
npm install @jooservices/react-config lucide-react
```

## Setup

```tsx
import "@jooservices/react-config/styles.css";
```

Pair with [`@jooservices/react-content`](https://www.npmjs.com/package/@jooservices/react-content) for page shell layout.

## Usage

```tsx
import { ConfigPanel, type ConfigEntry, type ConfigTabDef } from "@jooservices/react-config";
import { Bot, Globe2 } from "lucide-react";

const tabs: ConfigTabDef[] = [
  { id: "crawl", label: "Crawl", icon: Globe2, filter: (entry) => entry.meta?.section === "crawl" },
  { id: "ai", label: "AI & Search", icon: Bot, groups: ["Vector search"] },
  { id: "raw", label: "Raw store", mode: "raw" },
];

<ConfigPanel
  tabs={tabs}
  generalTab={{ label: "General" }}
  entries={curatedEntries}
  rawEntries={rawConfigs}
  onSave={async ({ path, type, value, editing }) => {
    // PATCH or POST via your API client
  }}
  onDelete={async (path) => {
    // DELETE via your API client
  }}
/>
```

### Tab mapping rules

1. `filter(entry)` — custom matcher (highest priority)
2. `groups: string[]` — match `entry.group_label`
3. Unmatched entries → **General** tab (hidden when empty by default)

## Exports

| Export | Purpose |
|--------|---------|
| `ConfigPanel` | Full UI: tabs, search, toggles, browser, dialog |
| `ConfigTreeBrowser` | Lower-level grouped rows (custom layouts) |
| `ConfigRecordForm` | Modal form only |
| `resolveEntryTabId`, `partitionEntriesByTab` | Tab routing helpers |

## License

MIT
