# @jooservices/react-layout

Master app shell for React — XFlickr-style grid with aligned brand column and sidebar width.

**Primary header API:** `AppShell.HeaderBar` (fixed roles: brand → nav menus → search → actions + user). There is **no** light/dark theme switcher in this package.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/layout"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Setup

```tsx
import "@jooservices/react-layout/styles.css";
```

## HeaderBar (recommended)

```tsx
import { AppShell, type AppShellLinkComponent } from "@jooservices/react-layout";
import { Boxes, Home, Settings2, Users } from "lucide-react";
import { Link } from "react-router-dom";

const RouterLink: AppShellLinkComponent = ({ href, className, children, onClick }) => (
  <Link to={href} className={className} onClick={onClick}>
    {children}
  </Link>
);

<AppShell sidebarWidth="16rem">
  <AppShell.HeaderBar
    brand={{ href: "/", title: "My App", logo: <Logo /> }}
    nav={[
      { label: "Overview", href: "/", active: true, icon: <Home aria-hidden /> },
      {
        label: "Admin",
        icon: <Settings2 aria-hidden />,
        children: [
          { label: "Config", href: "/config", icon: <Settings2 aria-hidden /> },
          { label: "Users", href: "/users", icon: <Users aria-hidden /> },
        ],
      },
    ]}
    search={{
      value: query,
      onChange: setQuery,
      onSubmit: runSearch,
      placeholder: "Search movies…",
    }}
    actions={[{ label: "Ops", href: "/ops" }]}
    user={{
      name: "Ada",
      items: [
        { label: "Profile", href: "/profile" },
        { label: "Sign out", onClick: logout },
      ],
    }}
    guest={<a href="/login">Sign in</a>}
    linkComponent={RouterLink}
  />
  <AppShell.Body>
    <AppShell.Sidebar footer={<>footer</>}>{/* nav links */}</AppShell.Sidebar>
    <AppShell.Main>
      <AppShell.MainFrame>{/* page content / Outlet */}</AppShell.MainFrame>
      <AppShell.FooterBar
        nav={footerNav}
        search={{
          value: query,
          onChange: setQuery,
          onSubmit: runSearch,
          placeholder: "Search movies…",
        }}
        actions={footerActions}
        user={footerUser}
        linkComponent={RouterLink}
      />
    </AppShell.Main>
  </AppShell.Body>
</AppShell>;
```

Nav / action / user menu items accept optional `icon?: ReactNode` (typically a Lucide element).

## FooterBar

`AppShell.FooterBar` shares `ShellBar` chrome with `HeaderBar` (nav / search / actions / user). Dropdowns open **up**. `brand` is optional — omit it when the footer sits under `Main` (no logo column).

Sidebar always renders a matching bottom rail (`footer` children optional).

Low-level slots (`Brand`, `HeaderNav`, `HeaderCenter`, …) remain for rare custom composition; prefer `HeaderBar` / `FooterBar` for JOO apps.

Pair with [`@jooservices/react-content`](`@jooservices/react-content` (git install)) inside `MainFrame`.
