# @jooservices/react-ui

Shared UI primitives for React apps — colored status controls with Lucide icons.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/ui"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Setup

Import theme once in your app entry:

```ts
import "@jooservices/react-ui/styles.css";
```

## Usage

```tsx
import { StatusToggle } from "@jooservices/react-ui";

<StatusToggle
  status="active"
  pending={mutation.isPending}
  onActivate={() => activate()}
  onDisable={() => disable()}
/>;
```

`pending_review` and `failed` render a read-only `StatusIndicator` automatically.

## API

| Export | Description |
|--------|-------------|
| `StatusToggle` | Interactive button for `active` ↔ `disabled` (`pending`, `size` `sm`\|`md`, `showLabel`) |
| `StatusIndicator` | Read-only pill for any `StatusValue` |
| `StatusValue` | `"active" \| "disabled" \| "pending_review" \| "failed"` |

Full prop tables: `docs/02-user-guide/01-react-ui.md`.
