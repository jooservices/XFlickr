# @jooservices/react-table

Ready-to-use `DataTable` for React apps — shadcn-compatible theme (CSS variables + bundled styles) with TanStack Table for sort, selection, and row state.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/table"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

Prefer `@jooservices/react-action-buttons` for header and row action UI.

## Setup (any React + Vite/CRA/Next app)

Import theme once in your app entry:

```ts
import "@jooservices/react-table/styles.css";
import "@jooservices/react-action-buttons/styles.css";
```

No Tailwind config required — styles ship with the package (`joo-*` CSS + theme variables). Works standalone in any React 18+ project.

## Usage

```tsx
import { ActionBar, ActionMenu, Button } from "@jooservices/react-action-buttons";
import { DataTable, type DataTableColumn } from "@jooservices/react-table";
import { MoreHorizontal, Pencil, Plus, Trash2 } from "lucide-react";

type User = { id: number; name: string; email: string };

const columns: DataTableColumn<User>[] = [
  { key: "name", label: "Name", sortable: true, render: (row) => row.name },
  { key: "email", label: "Email", render: (row) => row.email },
];

<DataTable
  title="Users"
  subtitle="120 accounts"
  headerActions={
    <ActionBar>
      <Button variant="ghost" size="icon" intent="create" icon={<Plus size={16} />} aria-label="Add user" onClick={() => openCreate()} />
      <ActionMenu
        label="More"
        intent="more"
        icon={<MoreHorizontal size={16} />}
        items={[{ label: "Export CSV", onClick: () => exportCsv() }]}
      />
    </ActionBar>
  }
  toolbar={<input placeholder="Filter…" />}
  columns={columns}
  data={users}
  rowKey={(user) => String(user.id)}
  rowActions={(user) => (
    <ActionBar>
      <Button
        size="sm"
        intent="edit"
        icon={<Pencil size={14} />}
        aria-label={`Edit ${user.name}`}
        onClick={() => edit(user)}
      />
      <ActionMenu
        label="More"
        intent="more"
        size="sm"
        items={[
          {
            label: "Delete",
            intent: "delete",
            icon: <Trash2 size={14} />,
            onClick: () => remove(user),
          },
        ]}
      />
    </ActionBar>
  )}
  sort={{ key: sortKey, direction: sortDirection, onChange: handleSort }}
  pagination={{ page, lastPage, total, onPageChange: setPage }}
  selection={{ selectedKeys, onChange: setSelectedKeys }}
  footer={<span>Server-side paging</span>}
/>
```

## API

| Prop | Description |
|------|-------------|
| `title` / `subtitle` | Header left |
| `headerActions` | Header right — `ReactNode` (compose with action-buttons) |
| `toolbar` | Slot above table body |
| `columns` | Field columns; `sortable` when `sort` prop is set; optional `align` |
| `rowActions` | Last column — `(row) => ReactNode` (compose with action-buttons) |
| `actionsLabel` | Actions column header (default `"Actions"`) |
| `selection` | Optional checkbox column (first); supports `isRowSelectable` / `rowLabel` |
| `sort` | Server-side sort (`manualSorting` via TanStack) |
| `pagination` | Footer pagination |
| `footer` | Extra footer content (alongside selection / totals) |
| `loading` / `emptyMessage` | Body states |

Legacy helpers (`TableActions`, `TableActionButton`, `TableHeaderIconAction`, `TableAction`) remain available for apps that still build table-local menus without action-buttons.

Business actions (`onClick`, API calls) are always defined by your app.

## License

MIT
