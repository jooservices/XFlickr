# @jooservices/react-content

Composable page layout shell for React — identity header, toolbar, advanced filters, main content slot, footer. Pairs with [`@jooservices/react-table`](https://www.npmjs.com/package/@jooservices/react-table).

## Install

```bash
npm install @jooservices/react-content lucide-react
```

## Setup

```tsx
import "@jooservices/react-content/styles.css";
```

## Usage

```tsx
import {
  PageShell,
  PageShellIdentity,
  PageShellToolbar,
  PageShellAdvanced,
  PageShellCanvas,
  PageShellFooter,
} from "@jooservices/react-content";

<PageShell>
  <PageShellIdentity
    title="Movies"
    subtitle="Browse catalog titles."
    actions={<button type="button">Add</button>}
  />
  <PageShellToolbar leading={<input type="search" />} trailing={<button type="button">Refresh</button>} />
  <PageShellAdvanced label="Advanced filters">
    {/* optional filter panel */}
  </PageShellAdvanced>
  <PageShellCanvas variant="plain">
    {/* table, grid, or form */}
  </PageShellCanvas>
  <PageShellFooter>{/* pagination */}</PageShellFooter>
</PageShell>;
```

## Components

| Export | Role |
|--------|------|
| `PageShell` | Root vertical stack |
| `PageShellIdentity` | Title, subtitle, breadcrumbs, page actions |
| `PageShellControlBar` | Tabs + filters + actions (legacy grid layout) |
| `PageShellToolbar` | Search left, actions right (+ optional Filter/Clear form) |
| `PageShellAdvanced` | Collapsible advanced filters |
| `PageShellContextBar` | Inline notice / diagnostics bar |
| `PageShellCanvas` / `PageContent` | Main content slot (`plain` \| `card` \| `flush`) |
| `PageShellFooter` | Footer (pagination, meta) |

## Publish

```bash
export NPM_TOKEN=npm_...
./scripts/publish.sh
```
