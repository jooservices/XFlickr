# @jooservices/react-table

Ready-to-use `DataTable` for React apps — shadcn-compatible theme (CSS variables + bundled styles) with TanStack Table for sort, selection, and row state.

## Install

```bash
npm install @jooservices/react-table lucide-react
# or
pnpm add @jooservices/react-table lucide-react
```

Peer dependencies: `react`, `react-dom`, `lucide-react`.

## Setup (any React + Vite/CRA/Next app)

Import theme once in your app entry:

```ts
import "@jooservices/react-table/styles.css";
```

No Tailwind config required — styles ship with the package (`joo-*` CSS + theme variables). Works standalone in any React 18+ project.

## Usage

```tsx
import { DataTable, type DataTableColumn, type TableAction } from "@jooservices/react-table";
import { MoreHorizontal, Pencil, Plus, Trash2 } from "lucide-react";

type User = { id: number; name: string; email: string };

const columns: DataTableColumn<User>[] = [
  { key: "name", label: "Name", sortable: true, render: (row) => row.name },
  { key: "email", label: "Email", render: (row) => row.email },
];

const headerActions: TableAction[] = [
  { type: "single", label: "Add user", icon: <Plus size={16} />, onClick: () => openCreate() },
  {
    type: "multi",
    label: "More",
    icon: <MoreHorizontal size={16} />,
    items: [{ label: "Export CSV", onClick: () => exportCsv() }],
  },
];

<DataTable
  title="Users"
  subtitle="120 accounts"
  headerActions={headerActions}
  columns={columns}
  data={users}
  rowKey={(user) => String(user.id)}
  rowActions={(user) => [
    { type: "single", label: "Edit", icon: <Pencil size={14} />, onClick: () => edit(user) },
    {
      type: "multi",
      label: "More",
      items: [{ label: "Delete", variant: "danger", icon: <Trash2 size={14} />, onClick: () => remove(user) }],
    },
  ]}
  sort={{ key: sortKey, direction: sortDirection, onChange: handleSort }}
  pagination={{ page, lastPage, total, onPageChange: setPage }}
  selection={{ selectedKeys, onChange: setSelectedKeys }}
/>
```

## API

| Prop | Description |
|------|-------------|
| `title` / `subtitle` | Header left |
| `headerActions` | Header right — `single` button or `multi` icon dropdown |
| `columns` | Field columns; `sortable` when `sort` prop is set |
| `rowActions` | Last column — `single` or `multi` actions per row |
| `selection` | Optional checkbox column (first) |
| `sort` | Server-side sort (`manualSorting` via TanStack) |
| `pagination` | Footer pagination |
| `toolbar` | Slot above table body |
| `footer` | Extra footer content |

Business actions (`onClick`, API calls) are always defined by your app.

## License

MIT
