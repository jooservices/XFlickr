# @jooservices/react-config

Schema-driven configuration panel for React — declarative tabs, grouped browse rows, modal editor, optional raw store tab, and a **General** fallback for unmapped groups.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/config"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Setup

```tsx
import "@jooservices/react-config/styles.css";
```

Pair with [`@jooservices/react-content`](`@jooservices/react-content` (git install)) `PageShell` and [`@jooservices/react-action-buttons`](`@jooservices/react-action-buttons` (git install)) for page primary actions.

## Primary actions (required)

**Create / New / Publish / Export / other view-level CTAs** must live in `PageShellIdentity` → `actions` — **not** inside `ConfigPanel`.

```tsx
import { useRef } from "react";
import { ActionBar, Button } from "@jooservices/react-action-buttons";
import { ConfigPanel, type ConfigPanelHandle } from "@jooservices/react-config";
import { PageShell, PageShellIdentity, PageShellCanvas } from "@jooservices/react-content";
import { Plus } from "lucide-react";

const panelRef = useRef<ConfigPanelHandle>(null);

<PageShell>
  <PageShellIdentity
    title="Settings"
    actions={
      <ActionBar>
        <Button variant="primary" intent="create" icon={<Plus />} onClick={() => panelRef.current?.openCreate()}>
          New key
        </Button>
      </ActionBar>
    }
  />
  <PageShellCanvas>
    <ConfigPanel
      ref={panelRef}
      tabs={tabs}
      entries={curatedEntries}
      rawEntries={rawConfigs}
      onSave={async ({ path, type, value, editing }) => {
        /* PATCH or POST */
      }}
      onDelete={async (path) => {
        /* per-row delete handler; view-level bulk delete stays in Identity */
      }}
    />
  </PageShellCanvas>
</PageShell>
```

`ConfigPanel` does **not** render its own New / Create primary button. Row edit/delete remain local.

## Usage (panel only)

```tsx
import { ConfigPanel, type ConfigEntry, type ConfigTabDef } from "@jooservices/react-config";
import { Bot, Globe2 } from "lucide-react";

const tabs: ConfigTabDef[] = [
  { id: "crawl", label: "Crawl", icon: Globe2, filter: (entry) => entry.meta?.section === "crawl" },
  { id: "ai", label: "AI & Search", icon: Bot, groups: ["Vector search"] },
  { id: "raw", label: "Raw store", mode: "raw" },
];

<ConfigPanel
  tabs={tabs}
  generalTab={{ label: "General" }}
  entries={curatedEntries}
  rawEntries={rawConfigs}
  onSave={async ({ path, type, value, editing }) => {
    // PATCH or POST via your API client
  }}
  onDelete={async (path) => {
    // DELETE via your API client (row-level)
  }}
/>
```

### Tab mapping rules

1. `filter(entry)` — custom matcher (highest priority)
2. `groups: string[]` — match `entry.group_label`
3. Unmatched entries → **General** tab (hidden when empty by default)

## Exports

| Export | Purpose |
|--------|---------|
| `ConfigPanel` | Full UI: tabs, search, toggles, browser, dialog (`ref` → `openCreate`) |
| `ConfigPanelHandle` | Imperative `{ openCreate() }` for Identity primary Create |
| `ConfigTreeBrowser` | Lower-level grouped rows (custom layouts) |
| `ConfigRecordForm` | Modal form only |
| `resolveEntryTabId`, `partitionEntriesByTab` | Tab routing helpers |

## License

MIT
