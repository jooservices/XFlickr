# @jooservices/react-action-buttons

Shared action button primitives — separate or grouped bars, dropdown menus, and split buttons.

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/action-buttons"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Setup

```ts
import "@jooservices/react-action-buttons/styles.css";
```

## Button colors (Bootstrap-inspired, JOO cyan-tuned)

| Variant | Look |
|---------|------|
| `primary` | Cyan brand CTA |
| `secondary` | Solid gray |
| `success` | Green |
| `danger` | Red (`destructive` alias) |
| `warning` | Amber |
| `info` | Lighter cyan |
| `light` | Soft surface |
| `dark` | Near-black strong CTA (former solid primary look) |
| `outline` | Bordered (default) |
| `ghost` | Transparent |

Export `BUTTON_VARIANTS` for galleries.

## Placement with PageShell (required)

**Primary / global view actions** → `PageShellIdentity` → `actions` only. **No exceptions.**

```tsx
import { ActionBar, Button } from "@jooservices/react-action-buttons";
import { PageShellIdentity } from "@jooservices/react-content";

<PageShellIdentity
  title="Movies"
  actions={
    <ActionBar>
      <Button variant="primary" intent="create">
        Create
      </Button>
    </ActionBar>
  }
/>
```

Other uses of this package (filters, row menus, empty states) are **local / isolated** — never a substitute for Identity Primary action. See `components/content/AGENTS.md`.

## Action → color guide (not enforced)

`intent` is optional. **`variant` always wins** when set.

| Intent | Suggested |
|--------|-----------|
| `create`, `save` | `primary` |
| `edit` | `secondary` |
| `export`, `cancel` | `outline` |
| `more`, `view` | `ghost` |
| `apply`, `publish` | `dark` |
| `delete`, `remove` | `danger` |

## Usage

```tsx
import { ActionBar, BUTTON_VARIANTS, Button } from "@jooservices/react-action-buttons";

<ActionBar>
  {BUTTON_VARIANTS.map((variant) => (
    <Button key={variant} variant={variant}>
      {variant}
    </Button>
  ))}
</ActionBar>;
```

## API

| Export | Description |
|--------|-------------|
| `Button` | `variant`, optional `intent` + `icon`, sizes `sm`\|`md`\|`icon` |
| `ActionBar` | `layout`: `separate` (default) / `group` |
| `ActionMenu` | Trigger + `items: ActionItem[]` |
| `SplitButton` | Primary `onClick` + overflow `items` |
| `Actions` | Declarative `ActionDescriptor[]` (`single` \| `menu` \| `split`) |
| `BUTTON_VARIANTS` | Ordered gallery list |
| `ACTION_COLOR_GUIDE` | Recommended intent → color |

Full prop tables and recipes: `docs/02-user-guide/08-react-action-buttons.md`.
