# @jooservices/react-layout

Master app shell for React — XFlickr-style grid with aligned brand column and sidebar width.

## Install

```bash
npm install @jooservices/react-layout lucide-react
```

## Setup

```tsx
import "@jooservices/react-layout/styles.css";
```

## Usage

```tsx
import { AppShell } from "@jooservices/react-layout";

<AppShell sidebarWidth="16rem">
  <AppShell.Header>
    <AppShell.Brand>{/* logo + app name */}</AppShell.Brand>
    <AppShell.HeaderMain>
      <AppShell.HeaderNav>{/* top menu */}</AppShell.HeaderNav>
      <AppShell.HeaderCenter>{/* search */}</AppShell.HeaderCenter>
      <AppShell.HeaderActions>{/* theme, user */}</AppShell.HeaderActions>
    </AppShell.HeaderMain>
    <AppShell.HeaderMobile>{/* mobile-only search */}</AppShell.HeaderMobile>
  </AppShell.Header>
  <AppShell.Body>
    <AppShell.Sidebar footer={<>footer</>}>{/* nav links */}</AppShell.Sidebar>
    <AppShell.Main>
      <AppShell.MainFrame>{/* page content / Outlet */}</AppShell.MainFrame>
    </AppShell.Main>
  </AppShell.Body>
</AppShell>;
```

Pair with [`@jooservices/react-content`](https://www.npmjs.com/package/@jooservices/react-content) inside `MainFrame`.
