# @jooservices/react-content

Composable page layout shell for React — identity header, toolbar, advanced filters, main content slot, footer. Pairs with [`@jooservices/react-table`](`@jooservices/react-table` (git install)).

## Install

```bash
pnpm add "github:jooservices/react#v1.0.0&path:components/content"
```

Peer dependencies: `react`, `react-dom` (>=18), `lucide-react` (>=0.400).

## Setup

```tsx
import "@jooservices/react-content/styles.css";
```

## Usage

```tsx
import { Clapperboard, Home } from "lucide-react";
import { ActionBar, Button } from "@jooservices/react-action-buttons";
import {
  PageShell,
  PageShellBanner,
  PageShellIdentity,
  PageShellToolbar,
  PageShellAdvanced,
  PageShellCanvas,
  PageShellFooter,
} from "@jooservices/react-content";

<PageShell>
  {flash ? (
    <PageShellBanner>
      {/* dismissible notice — app-owned chrome */}
      <p>{flash}</p>
    </PageShellBanner>
  ) : null}
  <PageShellIdentity
    title="Movies"
    subtitle="Browse catalog titles."
    breadcrumbs={[
      { label: "Catalog", href: "/", icon: <Home aria-hidden /> },
      { label: "Movies", icon: <Clapperboard aria-hidden /> },
    ]}
    actions={
      <ActionBar>
        <Button type="button" variant="primary" intent="create">
          Add
        </Button>
      </ActionBar>
    }
  />
  <PageShellToolbar leading={<input type="search" />} trailing={<button type="button">Refresh</button>} />
  <PageShellAdvanced label="Advanced filters">
    {/* optional filter panel */}
  </PageShellAdvanced>
  <PageShellCanvas variant="plain">
    {/* table, grid, or form */}
  </PageShellCanvas>
  <PageShellFooter>{/* pagination */}</PageShellFooter>
</PageShell>;
```

## Components

| Export | Role |
|--------|------|
| `PageShell` | Root vertical stack |
| `PageShellBanner` / `PageBanner` | Page-scoped flash / notice (first child; under app header) |
| `PageShellIdentity` | Title, subtitle, breadcrumbs (`label` / `href?` / `icon?`), **Primary action** (`actions`) |
| `PageShellControlBar` | Tabs + filters + **local** actions (not page primary) |
| `PageShellToolbar` | Search left, trailing controls (+ optional Filter/Clear form) |
| `PageShellAdvanced` | Collapsible advanced filters |
| `PageShellContextBar` | Inline notice / diagnostics bar |
| `PageShellCanvas` / `PageContent` | Main content slot (`plain` \| `card` \| `flush`) |
| `PageShellFooter` | Footer (pagination, meta) |

Breadcrumb items accept optional `icon?: ReactNode` (typically a Lucide element), same pattern as layout nav. Prefer `PageShellBanner` for top-of-page flash; keep `PageShellContextBar` for quieter inline diagnostics.

### Primary action placement (no exceptions)

View-level CTAs **must** go in `PageShellIdentity` → `actions`, composed with `@jooservices/react-action-buttons`. Do not place Create/Save/Publish (and other global view CTAs) only in the canvas or as ad-hoc buttons. Control-bar, row, and empty-state controls stay **local**.

## Distribution

Git tag + path only (see root docs). No npm publish script in this package.
